package org.acme;


public class MainApp {
    public static void main(String[] args) {
        System.out.println("Hello, World from Maven Project!");
    }
}
