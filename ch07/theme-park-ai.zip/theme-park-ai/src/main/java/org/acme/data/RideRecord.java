package org.acme.data;

public record RideRecord(String name, double rating) {
}
