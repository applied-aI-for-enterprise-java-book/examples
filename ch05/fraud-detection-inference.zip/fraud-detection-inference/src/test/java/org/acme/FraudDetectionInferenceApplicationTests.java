package org.acme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudDetectionInferenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
